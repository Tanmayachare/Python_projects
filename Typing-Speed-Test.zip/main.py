from time import *
import random as r

def error(a,b):
  error=0
  for i in range(len(a)):
    try:
      if a[i]!=b[i]:
        error+=1
    except:
      error+=1
  return error

lev = input(" 1)Beginner \n 2)Intermediate \n 3)Advance \n Choose level: \n ")

match lev:
    case "1":
        test=["Hello, how are you?","She likes to read books" "I like to play soccer",]

    case "2":
        test=["The cat chased the mouse.","The sun sets in the west.","They went for a picnic."]

    case "3":
        test=["The quick brown fox jumps over the lazy dog","Pack my box with five dozen liquor jugs","The algorithm efficiently solves complex problems."]

      
    case _:
        print("Invalide input")
      

test1=r.choice(test)
print(test1)
t1=time()
t_input=input("Type here:")
t2=time()

def speed():
  lenth=len(t_input)
  t3=round((t2-t1),2)
  ab=lenth/t3
  return round(ab,2)

print("Speed(w/sec):",speed())
print("Errors:",error(test1,t_input))


